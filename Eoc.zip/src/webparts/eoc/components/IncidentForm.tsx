import * as React from "react";
import styles from "../scss/Incidentform.module.scss";
import { TextField } from "office-ui-fabric-react/lib/TextField";
import { Dropdown, IDropdownOption } from "office-ui-fabric-react/lib/Dropdown";
import {
  IComboBoxOption,
  VirtualizedComboBox,
  Fabric,
  PrimaryButton,
  autobind,
} from "office-ui-fabric-react";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import PeoplePickers from "./PeoplePickers";
import cx from "classnames";
import {
  PeoplePicker,
  PrincipalType,
} from "@pnp/spfx-controls-react/lib/PeoplePicker";
import { sp } from "@pnp/sp";
import {
  SPHttpClient,
  SPHttpClientResponse,
  ISPHttpClientOptions,
} from "@microsoft/sp-http";
import { WebPartContext } from "@microsoft/sp-webpart-base";

import * as moment from "moment";
import siteconfig from "../config/siteconfig.json";
import { MSGraphClient } from "@microsoft/sp-http";

interface IUserDetail {
  ID: number;
  LoginName: string;
  UserName:string;
}
const IncudentStatus: IComboBoxOption[] = [
  { key: "P", text: "Planning (P)" },
  { key: "A", text: "Active (A)" },
  { key: "C", text: "Closed (C)" },
  { key: "T", text: "Testing (T)" },
];

const IncidentType: IComboBoxOption[] = [
  { key: "A", text: "Biological" },
  { key: "B", text: "Chemical" },
  { key: "C", text: "Coastal Storm" },
  { key: "D", text: "Dam/Levee Break" },
  { key: "E", text: "Drought" },
  { key: "G", text: "Earthquake" },
  { key: "H", text: "Explosion" },
  { key: "I", text: "Fire" },
  { key: "J", text: "Flood" },
];
export interface IncidentFormProps {
  context?:any;//: WebPartContext;
  onClickCancel: () => void;
  showSidebar?: boolean;
  callBack?: Function;
  siteUrl: string;
  Dashboard: () => void;
}
export interface IIncidentFormState {
  siteUrl: string;
  sitename: string;
  inclusionpath: string;
  siteId: any;  
  UserDetailsEocComander: Array<any>;
  UserDetailsIncidentComander: Array<any>;
  UserDetailsWatchOfficer: Array<any>;
  UserDetailsPublicInformationOfficer: Array<any>;
  UserDetailsLogisticCoordinator: Array<any>;  
  isShow: boolean;
  loggedinUserName: string;
  IncidentTypeDetails:Array<any>;
  IncidentStatusDetails:Array<any>;
  
  selectedusers: Array<any>;
  incidentDetails: ISPList;
}
export class ISPList {
  public IncidentName:string;
  public IncidentStatus:string;
  public IncidentType:string;
  public Location:string;
  public Description:string;
  public StartDateTime:string;
  public IncidentCommander:string;
  public EOCCoordinator:​​string;
  public WatchOfficer:​​​string;  
  public PublicInformationOfficer:​​​​string;
  public LogisticsCoordinator:​​​​​string;
  public IsActive:boolean;
  public TeamId:string;
  public Title:string;
}
export default class IncidentForm extends React.Component<
  IncidentFormProps,
  IIncidentFormState
> {  

  constructor(props: any) {
    super(props);
    sp.setup({
      spfxContext: this.props.context, 
    });
    this.state = {
      siteUrl: this.props.siteUrl,
      IncidentTypeDetails:[],
      IncidentStatusDetails:[], 
      sitename: siteconfig.sitename,
      inclusionpath: siteconfig.inclusionPath,
      siteId: "",
      isShow: false,
      loggedinUserName: "",
      selectedusers: [],
      incidentDetails:new ISPList(),
      UserDetailsEocComander: [],
      UserDetailsIncidentComander:[],
      UserDetailsWatchOfficer: [],
      UserDetailsPublicInformationOfficer: [],
      UserDetailsLogisticCoordinator: [],
    };
    
    this.handleInput = this.handleInput.bind(this);
    this.filterDropdownvalues=this.filterDropdownvalues.bind(this);
    this._createorupdateItem=this._createorupdateItem.bind(this);
    this._getListData=this._getListData.bind(this);
    } 
  public handleInput(event: any, key: string) {
    let incidentInfo = this.state.incidentDetails;
    incidentInfo[key] = event.target.value;
    this.setState({ incidentDetails: incidentInfo });
  }
 
  @autobind
  private _getPeoplePickerItems_EocComander(items: any[]) {
    let userarr: IUserDetail[] = [];
    items.forEach((user) => {
      userarr.push({ ID: user.id, LoginName: user.loginName,UserName: user.text });
    });
    this.setState({ UserDetailsEocComander: userarr });
  }
  @autobind
  private _getPeoplePickerItems_IncidentComander(items: any[]) {
    let userarr: IUserDetail[] = [];
    items.forEach((user) => {
      userarr.push({ ID: user.id, LoginName: user.loginName,UserName: user.text });
    });
    this.setState({ UserDetailsIncidentComander: userarr });
  }

  @autobind
  private _getPeoplePickerItems_LogisticCoordinator(items: any[]) {
    let userarr: IUserDetail[] = [];
    items.forEach((user) => {
      userarr.push({ ID: user.id, LoginName: user.loginName,UserName: user.text });
    });
    this.setState({ UserDetailsLogisticCoordinator: userarr });
  }
 
  @autobind
  private _getPeoplePickerItems_WatchOfficer(items: any[]) {
    let userarr: IUserDetail[] = [];
    items.forEach((user) => {
      userarr.push({ ID: user.id, LoginName: user.loginName,UserName: user.text });
    });
    this.setState({ UserDetailsWatchOfficer: userarr });
  }
  @autobind
  private _getPeoplePickerItems_PublicInformationOfficer(items: any[]) {
    let userarr: IUserDetail[] = [];
    items.forEach((user) => {
      userarr.push({ ID: user.id, LoginName: user.loginName,UserName: user.text });
    });
    this.setState({ UserDetailsPublicInformationOfficer: userarr });
  }
  public handleInputDate(event: any, key: string) {
    let incidentInfo = this.state.incidentDetails;
    incidentInfo[key] =  event.target.value;
    this.setState({ incidentDetails: incidentInfo });
  }
  public filterDropdownvalues(type: string, value: any) {
    if (value.target.innerText !== "All") {
      this.setState({
        incidentDetails: {
          ...this.state.incidentDetails,
          [type]: value.target.innerText,
        },
      });
    }
  }
  public optionsIncidentType() {
    let optionArray = [];
    let optionArrayIds = [];
    if (this.state.IncidentTypeDetails.length == 0)
      this.props.context.spHttpClient
        .get(
          this.state.siteUrl +
            "/" +
            this.state.inclusionpath +
            "/" +
            this.state.sitename +
            "/_api/web/lists/GetByTitle('Incident Type')/Items",
          SPHttpClient.configurations.v1
        )
        .then(async (response: SPHttpClientResponse) => {
          if (response.status === 200) {
            await response.json().then((responseJSON: any) => {
              let i = 0;
              while (i < responseJSON.value.length) {
                if (
                  responseJSON.value[i] &&
                  responseJSON.value[i].hasOwnProperty("Title")
                ) {
                  optionArray.push(responseJSON.value[i].Title);
                  optionArrayIds.push({
                    Title: responseJSON.value[i].Title,
                    Id: responseJSON.value[i].Id,
                  });
                  i++;
                }
              }
              this.setState({
                IncidentTypeDetails: optionArray, 
              });
            });
          }
        })
        .catch(() => {
          throw new Error("Asynchronous error");
        });

    let myOptions = [];
    myOptions.push({ key: "Select Incident Type", text: "Select Incident Type" });
    this.state.IncidentTypeDetails.forEach((element: any) => {
      myOptions.push({ key: element, text: element });
    });
    return myOptions;
  } 

   
  public optionsIncidentStatus() {
    let optionArray = [];
    let optionArrayIds = [];
    if (this.state.IncidentStatusDetails.length == 0)
      this.props.context.spHttpClient
        .get(
          this.state.siteUrl +
            "/" +
            this.state.inclusionpath +
            "/" +
            this.state.sitename +
            "/_api/web/lists/GetByTitle('Incident Status')/Items",
          SPHttpClient.configurations.v1
        )
        .then(async (response: SPHttpClientResponse) => {
          if (response.status === 200) {
            await response.json().then((responseJSON: any) => {
              let i = 0;
              while (i < responseJSON.value.length) {
                if (
                  responseJSON.value[i] &&
                  responseJSON.value[i].hasOwnProperty("Title")
                ) {
                  optionArray.push(responseJSON.value[i].Title);
                  optionArrayIds.push({
                    Title: responseJSON.value[i].Title,
                    Id: responseJSON.value[i].Id,
                  });
                  i++;
                }
              }
              this.setState({
                IncidentStatusDetails: optionArray, 
              });
            });
          }
        })
        .catch(() => {
          throw new Error("Asynchronous error");
        });

    let myOptions = [];
    myOptions.push({ key: "Select Incident Status", text: "Select Incident Status" });
    this.state.IncidentStatusDetails.forEach((element: any) => {
      myOptions.push({ key: element, text: element });
    });
    return myOptions;
  }
  private async _getListData(name: any): Promise<any> {
    return this.props.context.spHttpClient
      .get(
        this.state.siteUrl +
            "/" +
            this.state.inclusionpath +
            "/" +
            this.state.sitename +
            "/_api/web/lists/GetByTitle('IncidentTransaction')/Items",
        SPHttpClient.configurations.v1
      )
      .then(async (response: SPHttpClientResponse) => {
        if (response.status === 200) {
          let flag = 0;
          await response.json().then((responseJSON: any) => {
            let i = 0;
            while (i < responseJSON.value.length) {
              if (
                responseJSON.value[i].Title == name
              ) {
                flag = 1;
                return flag;
              }
              i++;
            }
            return flag;
          });
          return flag;
        }
      });
  }

  public async _createorupdateItem() {
    
    let incidentInfo : ISPList= this.state.incidentDetails;
    if (this.state.UserDetailsEocComander.length > 0) {
      incidentInfo.EOCCoordinator = this.state.UserDetailsEocComander[0].UserName;
    }
    if (this.state.UserDetailsIncidentComander.length > 0) {
      incidentInfo.IncidentCommander = this.state.UserDetailsIncidentComander[0].UserName;
    }
    if (this.state.UserDetailsWatchOfficer.length > 0) {
      incidentInfo.WatchOfficer = this.state.UserDetailsWatchOfficer[0].UserName;
    }
    if (this.state.UserDetailsLogisticCoordinator.length > 0) {
      incidentInfo.LogisticsCoordinator = this.state.UserDetailsLogisticCoordinator[0].UserName;
    }
    if (this.state.UserDetailsPublicInformationOfficer.length > 0) {
      incidentInfo.PublicInformationOfficer = this.state.UserDetailsPublicInformationOfficer[0].UserName;
    }
    incidentInfo.IsActive=true;
    incidentInfo.TeamId="testteamid";
    incidentInfo.StartDateTime=incidentInfo.StartDateTime;
    incidentInfo.Title=incidentInfo.IncidentName;
    const incidentinfo1:any={"Title":incidentInfo.Title,
    "Description":incidentInfo.Description,
    "IncidentType":incidentInfo.IncidentType,
    "IncidentStatus":incidentInfo.IncidentStatus
    ,"IncidentCommander":incidentInfo.IncidentCommander, 
    "EOCCommander":incidentInfo.EOCCoordinator,
    "WatchOfficer":incidentInfo.WatchOfficer,
    "PublicInformationOfficer":incidentInfo.PublicInformationOfficer,
    "LogisticsCoordinator":incidentInfo.LogisticsCoordinator,
    "IsActive":incidentInfo.IsActive,
    "TeamId":"sdfsdf",
    "StartDateTime":moment(incidentInfo.StartDateTime).format("YYYY-MM-DDThh:mmZ"),
    "Location":incidentInfo.Location,
    "IncidentName":incidentInfo.IncidentName};
    const spHttpClientOptions: ISPHttpClientOptions = {
      body: JSON.stringify(incidentinfo1),
    };

   // let flag = await this._getListData(incidentInfo.IncidentName);
    if (await this._getListData(incidentInfo.IncidentName) == 0) {
      const url: string =  this.state.siteUrl +
      "/" +
      this.state.inclusionpath +
      "/" +
      this.state.sitename +
      "/_api/web/lists/GetByTitle('IncidentTransaction')/Items";
      if (this.props.context)
        this.props.context.spHttpClient
          .post(url, SPHttpClient.configurations.v1, spHttpClientOptions)
          .then((response: SPHttpClientResponse) => {
            if (response.status === 201) {
              alert("Incident Transaction saved successful");
              {
                this.props.onClickCancel();
              }
            } else {
              alert(
                "Response status " +
                  response.status +
                  " - " +
                  response.statusText
              );
            }
          });
    } else {
      alert("Record Already Exist");
      {
        this.props.onClickCancel();
      }
    }
   this.setState({
      incidentDetails: new ISPList(),
      UserDetailsEocComander: [],
      UserDetailsIncidentComander:[],
      UserDetailsWatchOfficer: [],
      UserDetailsPublicInformationOfficer: [],
      UserDetailsLogisticCoordinator: [],selectedusers: []
    });

  }
   
  public render(){
  return (
    <div className={styles.incident}>
      <h3 className={styles.h3}>Incident Emergency Operation</h3>
      <h6 className={styles.h6}>Incident Details</h6>
      <Row>
        <Col md={6} lg="6">
          <TextField
            label="Incident Name:"
            required
            placeholder="Enter text here"
            value={
              this.state.incidentDetails.IncidentName
                ? this.state.incidentDetails.IncidentName
                : ""
            }
            onChange={(evt) => this.handleInput(evt, "IncidentName")}
          />
          <TextField label="Location:" required placeholder="Enter text here" 
          value={
            this.state.incidentDetails.Location
              ? this.state.incidentDetails.Location
              : ""
          }
          onChange={(evt) => this.handleInput(evt, "Location")}/>
          <TextField
            label="Incident Description:"
            multiline
            resizable={false}
            placeholder="Enter text here"
            value={
              this.state.incidentDetails.Description
                ? this.state.incidentDetails.Description
                : ""
            }
            onChange={(evt) => this.handleInput(evt, "Description")}
          />
        </Col>
        <Col md={6} lg="6">
          <Dropdown
            label="Incident Status:"
            //selectedKey={this.state.selectedItem ? selectedItem.key : undefined}
            onChange={(event: any) => this.filterDropdownvalues("IncidentStatus", event)}               
            placeholder="Select an incident"
            options={this.optionsIncidentStatus()}
          />
          <Fabric className="ms-ComboBoxExample">
          <Dropdown
            label="Incident Type:"
            //selectedKey={this.state.selectedItem ? selectedItem.key : undefined}
            onChange={(event: any) => this.filterDropdownvalues("IncidentType", event)}               
            placeholder="Select an incident Type"
            options={this.optionsIncidentType()}
          />
            </Fabric>
          <TextField
            label="Start Date & Time:​"
            id="datetime-local"
            type="datetime-local"
            defaultValue={""}
            value={
              this.state.incidentDetails.StartDateTime
                ? this.state.incidentDetails.StartDateTime
                : ""
            }
            onChange={(evt:any) => this.handleInputDate(evt, "StartDateTime")}
          />
        </Col>
      </Row>
      <h6 className={cx("mt-4", styles.h6)}>Role Assignments</h6>
      <Row className="mt-4">
        <Col md={6} lg="6">
          <label htmlFor="IC">Incident Commander:​</label>
          <PeoplePicker 
          context={this.props.context} 
            personSelectionLimit={3}
            placeholder="Enter Incident Commander search" 
            showtooltip={true}
            required={true}
            onChange={this._getPeoplePickerItems_IncidentComander}
            showHiddenInUI={false}
            principalTypes={[PrincipalType.User]}
            defaultSelectedUsers={this.state.selectedusers}
            resolveDelay={1000}
          />
        </Col>
        <Col md={6} lg="6">
          <label htmlFor="EOCC">EOC Coordinator:​​</label>
          <PeoplePicker 
          context={this.props.context} 
            personSelectionLimit={3}
            placeholder="Enter EOC Coordinator search" 
            showtooltip={true}
            required={true}
            onChange={this._getPeoplePickerItems_EocComander}
            showHiddenInUI={false}
            principalTypes={[PrincipalType.User]}
            defaultSelectedUsers={this.state.selectedusers}
            resolveDelay={1000}
          />
        </Col>
        <Col md={6} lg="6">
          <label htmlFor="WO">Watch Officer:​​​</label>
          <PeoplePicker 
          context={this.props.context} 
            personSelectionLimit={3}
            placeholder="Enter Watch Officer search" 
            showtooltip={true}
            required={true}
            onChange={this._getPeoplePickerItems_WatchOfficer}
            showHiddenInUI={false}
            principalTypes={[PrincipalType.User]}
            defaultSelectedUsers={this.state.selectedusers}
            resolveDelay={1000}
          />
        </Col>
        <Col md={6} lg="6">
          <label htmlFor="PIO">Public Information​ Officer:​​​​</label>
          <PeoplePicker 
          context={this.props.context} 
            personSelectionLimit={3}
            placeholder="Enter Public Information​ Officer search" 
            showtooltip={true}
            required={true}
            onChange={this._getPeoplePickerItems_PublicInformationOfficer}
            showHiddenInUI={false}
            principalTypes={[PrincipalType.User]}
            defaultSelectedUsers={this.state.selectedusers}
            resolveDelay={1000}
          />
        </Col>
        <Col md={6} lg="6">
          <label htmlFor="LC">Logistics ​ Coordinator:​​​​​</label>
          
          <PeoplePicker 
          context={this.props.context} 
            personSelectionLimit={3}
            placeholder="Enter Logistics ​ Coordinator search" 
            showtooltip={true}
            required={true}
            onChange={this._getPeoplePickerItems_LogisticCoordinator}
            showHiddenInUI={false}
            principalTypes={[PrincipalType.User]}
            defaultSelectedUsers={this.state.selectedusers}
            resolveDelay={1000}
          />
        </Col>
      </Row> 
       <div className="text-align-center mt-4 d-flex mx-auto">
        <PrimaryButton
          text="Go to Dashboard"
          allowDisabledFocus
          className="d-flex mx-auto"
          onClick={this.props.Dashboard}
        /> 
        
        <PrimaryButton
        text="Create Team for Incident"
        className="d-flex mx-auto"
        allowDisabledFocus  onClick={this._createorupdateItem}
      />
      </div>
    </div>
  );
}
  }