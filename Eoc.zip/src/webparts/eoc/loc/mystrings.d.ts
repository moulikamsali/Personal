declare interface IEocWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'EocWebPartStrings' {
  const strings: IEocWebPartStrings;
  export = strings;
}
