/* tslint:disable */
require("./Employeeview.css");
const styles = {

};

export default styles;
/* tslint:enable */