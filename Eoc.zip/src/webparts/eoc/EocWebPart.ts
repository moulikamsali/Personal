import * as React from 'react';
import * as ReactDom from 'react-dom';
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-webpart-base';

import * as strings from 'EocWebPartStrings';
import Eoc from './components/Eoc';
import { IEocProps } from './components/IEocProps';
import { IEocHomeProps } from './components/IEocHomeProps';
import EocHome from './components/EocHome';
export interface IEocWebPartProps {
  description: string; 
}

export default class EocWebPart extends BaseClientSideWebPart<IEocWebPartProps> {

  public render(): void {
    const element: React.ReactElement<IEocHomeProps > = React.createElement(
      EocHome,
      {
        description: this.properties.description,
        context: this.context,
        // passing siteUrl here for mutlti tenant.
        siteUrl: 'https://m365x374010.sharepoint.com'//this.context.pageContext.web.absoluteUrl.replace(this.context.pageContext.web.serverRelativeUrl, ""),
      }

    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
