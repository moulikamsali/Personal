/* tslint:disable */
require("./Incidentform.module.css");
const styles = {
  incident: 'incident_b3cb9568',
  h3: 'h3_b3cb9568',
  h6: 'h6_b3cb9568'
};

export default styles;
/* tslint:enable */