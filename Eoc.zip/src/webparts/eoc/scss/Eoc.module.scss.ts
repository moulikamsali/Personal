/* tslint:disable */
require("./Eoc.module.css");
const styles = {
  eoc: 'eoc_6da22bca',
  container: 'container_6da22bca'
};

export default styles;
/* tslint:enable */