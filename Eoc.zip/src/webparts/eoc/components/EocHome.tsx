import * as React from "react";
import styles from "../scss/Eoc.module.scss";
import "bootstrap/dist/css/bootstrap.min.css";
import Header from "./Header";
import Media from "react-bootstrap/Media";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import {
  SPHttpClient,
  SPHttpClientResponse,
  ISPHttpClientOptions,
} from "@microsoft/sp-http";
import { initializeIcons } from "@uifabric/icons";
import { ThemeStyle } from "msteams-ui-styles-core"; 
import { MSGraphClient } from "@microsoft/sp-http";
import { IEocHomeProps } from "./IEocHomeProps";
import IncidentForm from "./IncidentForm";
import Dashboard from "./Dashboard";
import siteconfig from "../config/siteconfig.json"; 

initializeIcons();

  
export interface IEocHomeState {
  siteUrl: string;
  sitename: string;
  inclusionpath: string;
  siteId: any;
  isShow: boolean;
  loggedinUserName: string;
  IncidentForm: boolean;
  Dashboard: boolean;
}

export default class EocHome extends React.Component<
  IEocHomeProps,
  IEocHomeState
> {
  private _renderListAsync: Function;
  constructor(_props: any) {
    super(_props);
    this.state = {
      siteUrl: this.props.siteUrl, 
      sitename: siteconfig.sitename,
      inclusionpath: siteconfig.inclusionPath,
      siteId: "",
      isShow: false,
      loggedinUserName: "",
      Dashboard:true,
      IncidentForm:false,
    };
 
    this.rootSiteId = this.rootSiteId.bind(this);
  }

  public componentDidMount() {
   
    this.rootSiteId();

    this.props.context.spHttpClient
      .get(
        this.state.siteUrl +
          "/_api/SP.UserProfiles.PeopleManager/GetMyProperties",
        SPHttpClient.configurations.v1
      )
      .then((responseuser: SPHttpClientResponse) => {
        responseuser.json().then((datauser: any) => {
          this.setState({ loggedinUserName: datauser.DisplayName });
        });
      });
  }

  //create lists when you upload package into new tenant.

  private _createList() {
    let listname = siteconfig.lists[1].listName;
    const getListUrl: string =
      this.state.siteUrl +
      "/" +
      this.state.inclusionpath +
      "/" +
      this.state.sitename +
      `/_api/web/lists/GetByTitle('${listname}')/Items`;

    let memberListName = siteconfig.lists[0].listName;

    let getMemberListUrl =
      this.state.siteUrl +
      "/" +
      `/_api/web/lists/GetByTitle('${memberListName}')/Items`;

    let isMembersListNotExists = false;
    this.props.context.spHttpClient
      .get(getMemberListUrl, SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.status === 404) {
          isMembersListNotExists = true;
        }
      });

    this.props.context.spHttpClient
      .get(getListUrl, SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.status === 200) {
        } else {
          if (response.status === 404) {
            this.props.context.spHttpClient
              .get(
                this.state.siteUrl +
                  "/_api/SP.UserProfiles.PeopleManager/GetMyProperties",
                SPHttpClient.configurations.v1
              )
              .then((responseuser: SPHttpClientResponse) => {
                responseuser.json().then((datauser: any) => {
                  const createsiteUrl: string =
                    this.state.siteUrl + "/_api/SPSiteManager/create";
                  const siteDefinition: any = {
                    request: {
                      Title: this.state.sitename,
                      Url:
                        this.state.siteUrl +
                        "/" +
                        this.state.inclusionpath +
                        "/" +
                        this.state.sitename,
                      Lcid: 1033,
                      ShareByEmailEnabled: true,
                      Description: "Description",
                      WebTemplate: "STS#3",
                      SiteDesignId: "6142d2a0-63a5-4ba0-aede-d9fefca2c767",
                      Owner: datauser.Email,
                    },
                  };
                  const spHttpsiteClientOptions: ISPHttpClientOptions = {
                    body: JSON.stringify(siteDefinition),
                  };
                  this.props.context.spHttpClient
                    .post(
                      createsiteUrl,
                      SPHttpClient.configurations.v1,
                      spHttpsiteClientOptions
                    )
                    .then((siteresponse: SPHttpClientResponse) => {
                      if (siteresponse.status === 200) {
                        siteresponse.json().then((sitedata: any) => {
                          if (sitedata.SiteId) {
                            let lists = [];
                            siteconfig.lists.forEach((item) => {
                              let listColumns = [];
                              item.columns.forEach((element) => {
                                let column;
                                switch (element.type) {
                                  case "text":
                                    column = {
                                      name: element.name,
                                      text: {},
                                    };
                                    listColumns.push(column);
                                    break; 
                                  case "boolean":
                                    column = {
                                      name: element.name,
                                      boolean: {},
                                    };
                                    listColumns.push(column);
                                    break;
                                  case "dateTime":
                                    column = {
                                      name: element.name,
                                      dateTime: {},
                                    };
                                    listColumns.push(column);
                                    break;
                                  case "number":
                                    column = {
                                      name: element.name,
                                      number: {},
                                    };
                                    listColumns.push(column);
                                    break;
                                  default:
                                    break;
                                }
                              });
                              let list = {
                                displayName: item.listName,
                                columns: listColumns,
                                list: {
                                  template: "genericList",
                                },
                              };
                              lists.push(list);
                            });

                            lists.forEach((item) => {
                              let siteId =
                                   sitedata.SiteId;
                              if (
                                1
                              ) {
                                
                                this.createNewList(siteId, item); 
                              }
                            });
                          } else {
                            alert("Check your site does not exists already.");
                          }
                        });
                      } else {
                        alert("Check your site does not exists already.");
                      }
                    });
                });
              });
          } else {
            alert(
              "Something went wrong. " +
                response.status +
                " " +
                response.statusText
            );
          }
        }
      });
  }

  private createNewList(siteId: any, item: any) {
    this.props.context.msGraphClientFactory
      .getClient()
      .then(async (client: MSGraphClient) => {
        client
          .api("sites/" + siteId + "/lists")
          .version("v1.0")
          .header("Content-Type", "application/json")
          .responseType("json")
          .post(item, (errEocHome, _res, rawresponse) => {
            if (!errEocHome) {
              if (rawresponse.status === 201) {
                {
                  if (item.displayName === "Incident Type") {
                    siteconfig.IncidentTypeMasterData.forEach(
                      (eventData) => {
                        let eventDataList: any = {
                          Title: eventData.Title, 
                          Description: eventData.Description,
                          IsActive: true,
                        };
                        const spHttpClientOptions: ISPHttpClientOptions = {
                          body: JSON.stringify(eventDataList),
                        };

                        const url: string =
                          this.state.siteUrl +
                          "/" +
                          this.state.inclusionpath +
                          "/" +
                          this.state.sitename +
                          "/_api/web/lists/GetByTitle('Incident Type')/items";
                        this.props.context.spHttpClient
                          .post(
                            url,
                            SPHttpClient.configurations.v1,
                            spHttpClientOptions
                          )
                          .then(
                            (
                              newUserResponse: SPHttpClientResponse
                            ) => {
                              if (
                                newUserResponse.status === 201
                              ) {
                              } else {
                              }
                            }
                          ).catch(err=>{
                            console.log(err);
                          });
                      }
                    );
                  } else  if (item.displayName === "Incident Status") {
                    siteconfig.IncidentStatusMasterData.forEach(
                      (eventData) => {
                        let eventDataList: any = {
                          Title: eventData.Title, 
                          Description: eventData.Description,
                          IsActive: true,
                        };
                        const spHttpClientOptions: ISPHttpClientOptions = {
                          body: JSON.stringify(eventDataList),
                        };

                        const url: string =
                          this.state.siteUrl +
                          "/" +
                          this.state.inclusionpath +
                          "/" +
                          this.state.sitename +
                          "/_api/web/lists/GetByTitle('Incident Status')/items";
                        this.props.context.spHttpClient
                          .post(
                            url,
                            SPHttpClient.configurations.v1,
                            spHttpClientOptions
                          )
                          .then(
                            (
                              newUserResponse: SPHttpClientResponse
                            ) => {
                              if (
                                newUserResponse.status === 201
                              ) {
                              } else {
                              }
                            }
                          );
                      }
                    );
                  }
                }
              }
            }
          });
      });
  }

  private rootSiteId() {
    let graphSiteRoot = "sites/root";
    this.props.context.msGraphClientFactory
      .getClient()
      .then((garphClient: MSGraphClient) => {
        garphClient
          .api(graphSiteRoot)
          .version("v1.0")
          .header("Content-Type", "application/json")
          .responseType("json")
          .get()
          .then((data: any) => {
            this.setState({ siteId: data.id.split(",")[1] }, () => {
              this._createList();
            });
          })
          .catch((errEocHome) => {});
      });
  }



  public componentWillMount() {
      
  }

  public render(){
    return (
      <div className={styles.eoc}>
      <div className={styles.container}>
        <Header
          clickcallback={() =>
            this.setState({
              IncidentForm: false,
              Dashboard: true,
            })
          }
        />
        {!this.state.Dashboard ? (
           <IncidentForm siteUrl={this.state.siteUrl}
           context={this.props.context}
           callBack={this._renderListAsync}
           onClickCancel={() => this.setState({  })}
           Dashboard={() =>
             this.setState({ IncidentForm: false, Dashboard: true })}/>
        ) : (
          <Dashboard
            IncidentForm={() =>
              this.setState({ IncidentForm: true, Dashboard: false })
            }
          />
        )}
      </div>
    </div>
 
    );
  }
}
