/* tslint:disable */
require("./DigitalBadge.module.css");
const styles = {
  digitalBadge: 'digitalBadge_6af9c7b4',
  container: 'container_6af9c7b4',
  row: 'row_6af9c7b4',
  column: 'column_6af9c7b4',
  'ms-Grid': 'ms-Grid_6af9c7b4',
  title: 'title_6af9c7b4',
  subTitle: 'subTitle_6af9c7b4',
  description: 'description_6af9c7b4',
  button: 'button_6af9c7b4',
  label: 'label_6af9c7b4'
};

export default styles;
/* tslint:enable */