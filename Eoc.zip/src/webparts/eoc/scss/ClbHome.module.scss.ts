/* tslint:disable */
require("./ClbHome.module.css");
const styles = {
  clbHome: 'clbHome_8204a725',
  container: 'container_8204a725',
  navbg: 'navbg_8204a725',
  white: 'white_8204a725',
  imgheader: 'imgheader_8204a725',
  box: 'box_8204a725',
  grid: 'grid_8204a725',
  quickguide: 'quickguide_8204a725',
  cursor: 'cursor_8204a725',
  dashboardimgs: 'dashboardimgs_8204a725',
  center: 'center_8204a725',
  list: 'list_8204a725',
  mb: 'mb_8204a725',
  margintop: 'margintop_8204a725',
  badge: 'badge_8204a725',
  addmembers: 'addmembers_8204a725',
  load: 'load_8204a725',
  spin: 'spin_8204a725'
};

export default styles;
/* tslint:enable */