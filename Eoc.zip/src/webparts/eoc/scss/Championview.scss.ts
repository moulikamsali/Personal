/* tslint:disable */
require("./Championview.css");
const styles = {

};

export default styles;
/* tslint:enable */