import * as React from "react";
import styles from "../scss/Header.module.scss";
import Navbar from "react-bootstrap/Navbar";
interface IHeaderProps {
  clickcallback: () => void; //will redirects to home
}
export default class Header extends React.Component<IHeaderProps, {}> {
  constructor(props: any) {
    super(props);
    this.homeRedirect = this.homeRedirect.bind(this);
  }
  public homeRedirect() {
    this.props.clickcallback();
  }
  public render() {
    return (
      <Navbar className={styles.navbg}>
        <Navbar.Brand
          href="#home"
          className={styles.white}
          onClick={this.homeRedirect}
        >
          <img
            src={require("../assets/mslogo.png")}
            width="auto"
            height="40"
            alt="mslogo"
            className="d-inline-block align-center"
          />
          <span>Team Emergency Operations Center</span>
        </Navbar.Brand>
      </Navbar>
    );
  }
}
