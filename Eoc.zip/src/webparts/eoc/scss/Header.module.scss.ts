/* tslint:disable */
require("./Header.module.css");
const styles = {
  navbg: 'navbg_59c3e003',
  white: 'white_59c3e003'
};

export default styles;
/* tslint:enable */