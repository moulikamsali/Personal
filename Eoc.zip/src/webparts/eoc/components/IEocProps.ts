import { WebPartContext } from "@microsoft/sp-webpart-base";

export interface IEocProps {
  context: WebPartContext;
  description: string;
  siteUrl: string;
}
 