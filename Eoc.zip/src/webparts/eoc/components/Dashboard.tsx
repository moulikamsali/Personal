import * as React from "react";
import Table from "react-bootstrap/Table";
import { PrimaryButton } from "office-ui-fabric-react";

interface IDashboardProps {
  IncidentForm: () => void;
}
export default function Dashboard(props: IDashboardProps) {
  return (
    <div  className="px-2">
      <PrimaryButton
        text="Create a team for new incident​"
        allowDisabledFocus
        className="my-4 d-flex mx-auto"
        onClick={props.IncidentForm}
      />
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>Incident / Team Name</th>
            <th>Start Date</th>
            <th>Status</th>
            <th>Incident Commander</th>
            <th>Location</th>
            <th>End Date</th>
            <th>Incident ID</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>xyz</td>
            <td>xyz</td>
            <td>xyz</td>
            <td>xyz</td>
            <td>xyz</td>
            <td>xyz</td>
            <td>xyz</td>
          </tr>
          <tr>
            <td>xyz</td>
            <td>xyz</td>
            <td>xyz</td>
            <td>xyz</td>
            <td>xyz</td>
            <td>xyz</td>
            <td>xyz</td>
          </tr>
        </tbody>
      </Table>
    </div>
  );
}
