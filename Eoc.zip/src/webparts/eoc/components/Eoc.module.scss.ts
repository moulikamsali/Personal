/* tslint:disable */
require("./Eoc.module.css");
const styles = {
  eoc: 'eoc_d5ebe07b',
  container: 'container_d5ebe07b',
  row: 'row_d5ebe07b',
  column: 'column_d5ebe07b',
  'ms-Grid': 'ms-Grid_d5ebe07b',
  title: 'title_d5ebe07b',
  subTitle: 'subTitle_d5ebe07b',
  description: 'description_d5ebe07b',
  button: 'button_d5ebe07b',
  label: 'label_d5ebe07b'
};

export default styles;
/* tslint:enable */