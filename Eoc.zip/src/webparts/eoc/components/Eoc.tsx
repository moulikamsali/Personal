import * as React from "react";
import styles from "../scss/Eoc.module.scss";
import "bootstrap/dist/css/bootstrap.min.css";
import { IEocProps } from "./IEocProps";
import Header from "./Header";
import IncidentForm from "./IncidentForm";
import Dashboard from "./Dashboard";
export interface IEocState {
  IncidentForm: boolean;
  Dashboard: boolean;
}
export default class Eoc extends React.Component<IEocProps, IEocState> {
  constructor(props: any) {
    super(props);
    this.state = {
      IncidentForm: false,
      Dashboard: true,
    };
  }
  private _renderListAsync: Function;
  public render(): React.ReactElement<IEocProps> {
    return (
   
        <div className={styles.eoc}>
        <div className={styles.container}>
          <Header
            clickcallback={() =>
              this.setState({
                IncidentForm: false,
                Dashboard: true,
              })
            }
          />
          {!this.state.Dashboard ? (
            <IncidentForm
              Dashboard={() =>
                this.setState({ IncidentForm: false, Dashboard: true })}
                  siteUrl={this.props.siteUrl}
                  context={this.props.context}
                  callBack={this._renderListAsync}
                  onClickCancel={() => this.setState({ })}
                 
            />
          ) : (
            <Dashboard
              IncidentForm={() =>
                this.setState({ IncidentForm: true, Dashboard: false })
              }
            />
          )}
        </div>
      </div>
    );
  }
}
