/* tslint:disable */
require("./EocHome.module.css");
const styles = {
  eocHome: 'eocHome_a8d5284f',
  container: 'container_a8d5284f',
  navbg: 'navbg_a8d5284f',
  white: 'white_a8d5284f',
  imgheader: 'imgheader_a8d5284f',
  box: 'box_a8d5284f',
  grid: 'grid_a8d5284f',
  quickguide: 'quickguide_a8d5284f',
  cursor: 'cursor_a8d5284f',
  dashboardimgs: 'dashboardimgs_a8d5284f',
  center: 'center_a8d5284f',
  list: 'list_a8d5284f',
  mb: 'mb_a8d5284f',
  margintop: 'margintop_a8d5284f',
  badge: 'badge_a8d5284f',
  addmembers: 'addmembers_a8d5284f',
  load: 'load_a8d5284f',
  spin: 'spin_a8d5284f'
};

export default styles;
/* tslint:enable */