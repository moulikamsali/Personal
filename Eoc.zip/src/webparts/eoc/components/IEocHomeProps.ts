import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface IEocHomeProps {
  context: WebPartContext;
  description: string;
  siteUrl: string;
  
}
